//self executing anonymous function
(function() {
	"use strict";
console.log("SEAF has fired");	
//variables


//functions


//listeners	

})();